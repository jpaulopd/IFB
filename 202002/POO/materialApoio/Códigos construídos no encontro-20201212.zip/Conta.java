
public class Conta {
	// Atributos
	String agencia;
	String numero;
	String titular;
	Double saldo;
	
	//Método Construtor
	Conta(String numAgencia, String numConta, String nomeTitular, Double saldoInicial){
		System.out.println("Criando uma conta!");
		agencia = numAgencia;
		numero = numConta;
		titular = nomeTitular;
		
		if(saldoInicial == null) {
			saldo = 0.0;
		}else {
			saldo = saldoInicial;
		}
		
	}
	
	//Métodos
	void depositar(Double valor) {
		if(valor > 0.0) {
			saldo = saldo + valor;
		}else {
			System.err.println("Não é possível depositar valor negativo");
		}
		
	}
	
	Double saldo() {
		return saldo;
	}
	
	void sacar(Double valor){
		saldo = saldo - valor;
	}

}
