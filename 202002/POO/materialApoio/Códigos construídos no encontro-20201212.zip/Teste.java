
public class Teste {
	public static void main(String[] args) {
		
		Conta conta1 = new Conta("4353-2", "432423-6", "Caetano Veloso", null);
		
		conta1.agencia = "230502395";
		
		conta1.depositar(60.50);
		conta1.sacar(30.00);
		conta1.depositar(-45.32);
		System.out.println(conta1.saldo());
		System.out.println(conta1.titular);
	
		
	}

}
