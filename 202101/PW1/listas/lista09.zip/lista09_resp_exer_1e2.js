function somar(a,b){
    return a+b;
}

// exports.soma = function(w,s){
//     let x = w;
//     let y = s;
//     return somar(x,y);
// };

export function sum(x,y){
    // let x = w;
    // let y = s;
    return somar(x,y)
}