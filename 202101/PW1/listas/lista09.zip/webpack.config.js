module.exports = {
    entry: {
        main: './src/lista09_resp_exer_5.js'
    },
    output: {
        filename: 'main.js',
        library: 'exemplo'
    }
};