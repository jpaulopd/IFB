import{espaco,maiusculo,constante} from './lista09_resp_exer_5_src.js'

export function espac(){
    espaco();
}

export function maiuscul(){
    maiusculo();
}

export function constant(){
    constante();
}



