import {sum} from './lista09_resp_exer_1e2.js';

console.log( sum(6,8) );

// let m = require('./lista09_resp_exer_1e2')

// console.log( m.soma(5,3) );
